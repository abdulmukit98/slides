package com.example.lab02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btns;
    TextView tvS, tvN;
    EditText edtN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btns = findViewById(R.id.btnSubmit);
        tvS = findViewById(R.id.tvShow);
        tvN = findViewById(R.id.tvName);
        edtN = findViewById(R.id.edtName);

        btns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(),
                        "Hello Batch 27",
                        Toast.LENGTH_LONG).show();

                tvN.setText(edtN.getText().toString());
            }
        });
    }
}